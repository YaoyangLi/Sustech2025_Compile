package impl;

import framework.AbstractCompiler;
import framework.AbstractGrader;
import framework.llvm.IRBuilder;
import framework.llvm.IRType;
import framework.llvm.IRValue;
import generated.Splc.SplcBaseVisitor;
import generated.Splc.SplcLexer;
import generated.Splc.SplcParser;
import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;

import java.io.IOException;
import java.util.*;
import org.antlr.v4.runtime.misc.Pair;
import framework.llvm.FunctionBuilder;
import framework.llvm.BasicBlockBuilder;
import framework.llvm.LLVMIcmpPredicate;

public class Compiler extends AbstractCompiler {
    public Compiler(AbstractGrader grader) {
        super(grader);
    }

    @Override
    public void start() throws IOException {
        CharStream input = CharStreams.fromStream(this.grader.getSourceStream());
        SplcLexer lexer = new SplcLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        SplcParser parser = new SplcParser(tokens);

        // 1) 解析程序
        SplcParser.ProgramContext program = parser.program();

        // 2) 搭建 IRBuilder 与符号表骨架
        IRBuilder ir = new IRBuilder();
        Symbols symbols = new Symbols();

        // 3) 预声明标准库函数
        predeclareStdlib(ir);

        // 4) 两遍遍历：第一遍处理结构体、全局、函数原型；第二遍处理函数定义
        // 目前先搭建框架，具体翻译将在后续补充实现
        FirstPass first = new FirstPass(ir, symbols);
        first.visit(program);

        SecondPass second = new SecondPass(ir, symbols);
        second.visit(program);

        // 5) 输出 IR
        grader.printIR(ir);
    }

    /** 预声明标准库函数 */
    private void predeclareStdlib(IRBuilder ir) {
    ir.declareFunction("readint", IRType.int32(), List.of());
    ir.declareFunction("writeint", IRType.int32(), List.of(new Pair<>("x", IRType.int32())));
    ir.declareFunction("setseed", IRType.int32(), List.of(new Pair<>("s", IRType.int32())));
    ir.declareFunction("getrand", IRType.int32(), List.of());
    ir.declareFunction("assert_eq", IRType.int32(), List.of(new Pair<>("a", IRType.int32()), new Pair<>("b", IRType.int32()), new Pair<>("c", IRType.int32())));
    }

    /** 符号表集合 */
    private static class Symbols {
    // 结构体名 -> 字段 (name, type) 列表
    final Map<String, List<Pair<String, IRType>>> structs = new HashMap<>();
        // 函数签名
        final Map<String, FuncSig> functions = new HashMap<>();
    // 全局变量
    final Map<String, IRValue> globals = new HashMap<>();
    // 全局变量类型
    final Map<String, IRType> globalTypes = new HashMap<>();

        Symbols() {
            // 引用以避免未使用的检查报错
            structs.hashCode(); functions.hashCode(); globals.hashCode();
        }
    }

    private record FuncSig(String name, IRType ret, List<Pair<String, IRType>> params) {}

    /** 第一遍：顶层结构、全局、函数原型（占位实现） */
    private static class FirstPass extends SplcBaseVisitor<Void> {
    private final IRBuilder ir;
    private final Symbols symbols;

        FirstPass(IRBuilder ir, Symbols symbols) {
            this.ir = ir;
            this.symbols = symbols;
        }

        @Override
        public Void visitProgram(SplcParser.ProgramContext ctx) {
            // 引用字段避免未使用告警
            ir.hashCode(); symbols.hashCode();
            // 遍历顶层外部定义
            for (var child : ctx.children) {
                if (child instanceof SplcParser.GlobalDefContext gd) {
                    visit(gd);
                }
            }
            return null;
        }

        @Override
        public Void visitGlobalVarDef(SplcParser.GlobalVarDefContext ctx) {
            // specifier varDec ';'
            IRType base = toIRType(ctx.specifier());
            VarDecl vd = resolveVarDecl(base, ctx.varDec());
            IRType finalType = vd.arrayDims.isEmpty() ? vd.baseType : IRType.array(vd.baseType, vd.arrayDims.stream().mapToInt(Integer::intValue).toArray());
            IRValue gv = ir.defineGlobalVar(vd.name, finalType);
            symbols.globals.put(vd.name, gv);
            symbols.globalTypes.put(vd.name, finalType);
            return null;
        }

        @Override
        public Void visitFuncDecl(SplcParser.FuncDeclContext ctx) {
            String name = ctx.Identifier().getText();
            IRType ret = toIRType(ctx.specifier());
            List<Pair<String, IRType>> params = parseFuncArgs(ctx.funcArgs());
            ir.declareFunction(name, ret, params);
            symbols.functions.put(name, new FuncSig(name, ret, params));
            return null;
        }

        @Override
        public Void visitFullStructSpec(SplcParser.FullStructSpecContext ctx) {
            // 记录结构体字段名与类型，供后续成员访问使用
            String name = ctx.Identifier().getText();
            List<Pair<String, IRType>> fields = new ArrayList<>();
            List<IRType> typesForDef = new ArrayList<>();
            for (int i = 0; i < ctx.varDec().size(); i++) {
                IRType fty = toIRType(ctx.specifier(i));
                var vd = resolveVarDecl(fty, ctx.varDec(i));
                // construct the final field type: if the declarator contains array dimensions,
                // wrap the base type into nested array types so the struct field has the
                // correct complete type (e.g. int array[10][20] -> [10 x [20 x i32]] )
                IRType finalFieldType = vd.arrayDims.isEmpty() ? vd.baseType : IRType.array(vd.baseType, vd.arrayDims.stream().mapToInt(Integer::intValue).toArray());
                fields.add(new Pair<>(vd.name, finalFieldType));
                typesForDef.add(finalFieldType);
            }
            symbols.structs.put(name, fields);
            ir.defineStructure(name, typesForDef);
            return null;
        }

        private IRType toIRType(SplcParser.SpecifierContext spec) {
            if (spec instanceof SplcParser.IntSpecContext) return IRType.int32();
            if (spec instanceof SplcParser.CharSpecContext) return IRType.int32();
            if (spec instanceof SplcParser.StructDeclSpecContext s) {
                return IRType.structure(s.Identifier().getText());
            }
            if (spec instanceof SplcParser.FullStructSpecContext f) {
                return IRType.structure(f.Identifier().getText());
            }
            throw new RuntimeException("Unsupported type specifier");
        }

        private static class VarDecl {
            String name;
            IRType baseType;
            List<Integer> arrayDims = new ArrayList<>();
        }

        private VarDecl resolveVarDecl(IRType baseType, SplcParser.VarDecContext vd) {
            VarDecl out = new VarDecl();
            out.baseType = baseType;
            SplcParser.VarDecContext cur = vd;
            while (true) {
                if (cur instanceof SplcParser.SimpleVarContext s) {
                    out.name = s.Identifier().getText();
                    break;
                } else if (cur instanceof SplcParser.PointerVarContext p) {
                    out.baseType = IRType.pointer();
                    cur = p.varDec();
                } else if (cur instanceof SplcParser.ArrayVarContext a) {
                    // 后缀数组，需要读出尺寸并继续
                    int size = Integer.parseInt(a.Number().getText());
                    out.arrayDims.add(size);
                    cur = a.varDec();
                } else if (cur instanceof SplcParser.ParenVarContext par) {
                    cur = par.varDec();
                } else {
                    throw new RuntimeException("Unsupported var declarator");
                }
            }
            // ArrayVarContext 是左递归，累积的维度为从内到外，这里反转以匹配 IRType.array 顺序
            Collections.reverse(out.arrayDims);
            return out;
        }

        private List<Pair<String, IRType>> parseFuncArgs(SplcParser.FuncArgsContext args) {
            List<Pair<String, IRType>> list = new ArrayList<>();
            if (args == null) return list;
            List<SplcParser.SpecifierContext> specs = args.specifier();
            List<SplcParser.VarDecContext> vars = args.varDec();
            for (int i = 0; i < vars.size(); i++) {
                IRType base = toIRType(specs.get(i));
                VarDecl vd = resolveVarDecl(base, vars.get(i));
                if (!vd.arrayDims.isEmpty()) {
                    // 参数不允许数组：按约束直接抛错或降级为指针。此处简化为报错避免 UB。
                    throw new RuntimeException("Array type in parameter is not supported");
                }
                IRType ty = vd.baseType;
                String name = vd.name;
                list.add(new Pair<>(name, ty));
            }
            return list;
        }
    }

    /** 第二遍：函数定义（占位实现） */
    private static class SecondPass extends SplcBaseVisitor<Void> {
    private final IRBuilder ir;
    private final Symbols symbols;
        // temporary storage for pointer-depths of the last parsed function's parameters
        private Map<String, Integer> lastParamPtrDepths = new HashMap<>();
    // keep the declared (syntactic) parameter types for the last parsed function
    // separate from the actual function ABI types used when declaring the function.
    private Map<String, IRType> lastParamDeclaredTypes = new HashMap<>();

        SecondPass(IRBuilder ir, Symbols symbols) {
            this.ir = ir;
            this.symbols = symbols;
        }

        @Override
        public Void visitProgram(SplcParser.ProgramContext ctx) {
            ir.hashCode(); symbols.hashCode();
            for (var child : ctx.children) {
                if (child instanceof SplcParser.GlobalDefContext gd) {
                    visit(gd);
                }
            }
            return null;
        }

        @Override
        public Void visitFuncDef(SplcParser.FuncDefContext ctx) {
            String name = ctx.Identifier().getText();
            IRType ret = toIRType(ctx.specifier());
            List<Pair<String, IRType>> params = parseFuncArgs(ctx.funcArgs());
            FunctionBuilder fb = ir.defineFunction(name, ret, params);
            BasicBlockBuilder entry = fb.rootBlock();

            Codegen cg = new Codegen(ir, symbols, fb, entry, params, this.lastParamPtrDepths, this.lastParamDeclaredTypes);
            for (var st : ctx.statement()) {
                cg.emitStatement(st);
            }
            // 若未显式返回，插入一个默认返回 0（为简化基础测试）
            if (!entry.hasTerminated()) {
                entry.ret(IRValue.consti32(0));
            }
            return null;
        }

        private IRType toIRType(SplcParser.SpecifierContext spec) {
            if (spec instanceof SplcParser.IntSpecContext) return IRType.int32();
            if (spec instanceof SplcParser.CharSpecContext) return IRType.int32();
            if (spec instanceof SplcParser.StructDeclSpecContext s) {
                return IRType.structure(s.Identifier().getText());
            }
            if (spec instanceof SplcParser.FullStructSpecContext f) {
                return IRType.structure(f.Identifier().getText());
            }
            throw new RuntimeException("Unsupported type specifier");
        }

        private List<Pair<String, IRType>> parseFuncArgs(SplcParser.FuncArgsContext args) {
            List<Pair<String, IRType>> list = new ArrayList<>();
            Map<String, Integer> depthMap = new HashMap<>();
            Map<String, IRType> declaredMap = new HashMap<>();
            if (args == null) {
                this.lastParamPtrDepths = depthMap;
                this.lastParamDeclaredTypes = declaredMap;
                return list;
            }
            List<SplcParser.SpecifierContext> specs = args.specifier();
            List<SplcParser.VarDecContext> vars = args.varDec();
            for (int i = 0; i < vars.size(); i++) {
                IRType base = toIRType(specs.get(i));
                SplcParser.VarDecContext vd = vars.get(i);
                // resolve pointer/array modifiers
                SplcParser.VarDecContext cur = vd;
                List<Integer> arrDims = new ArrayList<>();
                IRType finalBase = base;
                int ptrDepth = 0;
                while (true) {
                    if (cur instanceof SplcParser.SimpleVarContext) {
                        break;
                    } else if (cur instanceof SplcParser.PointerVarContext p) {
                        finalBase = IRType.pointer();
                        ptrDepth++;
                        cur = p.varDec();
                    } else if (cur instanceof SplcParser.ArrayVarContext a) {
                        int size = Integer.parseInt(a.Number().getText());
                        arrDims.add(size);
                        cur = a.varDec();
                    } else if (cur instanceof SplcParser.ParenVarContext par) {
                        cur = par.varDec();
                    } else {
                        throw new RuntimeException("Unsupported var declarator in func def");
                    }
                }
                Collections.reverse(arrDims);
                IRType ty;
                // If the declarator is a pointer to an array (e.g. (*ptr)[N]) then
                // this should be represented as a pointer parameter (the array decays
                // to a pointer-to-array for the parameter). Avoid creating an
                // array-of-pointer type which would represent array-by-value.
                if (!arrDims.isEmpty() && finalBase.isPointer()) {
                    // This declarator is a pointer-to-array (e.g. T (*p)[N]).
                    // The declared (syntactic) type is an array whose elements are
                    // pointers (so we can later infer element shapes). However, the
                    // function ABI expects a pointer parameter (pointer to the
                    // array). Emit the function signature using an opaque pointer
                    // but remember the declared type separately for codegen.
                    IRType declared = IRType.array(finalBase, arrDims.stream().mapToInt(Integer::intValue).toArray());
                    declaredMap.put(extractVarName(vd), declared);
                    ty = IRType.pointer(); // function ABI: pointer
                } else {
                    ty = arrDims.isEmpty() ? finalBase : IRType.array(finalBase, arrDims.stream().mapToInt(Integer::intValue).toArray());
                    declaredMap.put(extractVarName(vd), ty);
                }
                String name = extractVarName(vd);
                depthMap.put(name, ptrDepth);
                list.add(new Pair<>(name, ty));
            }
            this.lastParamPtrDepths = depthMap;
            this.lastParamDeclaredTypes = declaredMap;
            return list;
        }

        private String extractVarName(SplcParser.VarDecContext vd) {
            SplcParser.VarDecContext cur = vd;
            while (true) {
                if (cur instanceof SplcParser.SimpleVarContext s) return s.Identifier().getText();
                if (cur instanceof SplcParser.PointerVarContext p) { cur = p.varDec(); continue; }
                if (cur instanceof SplcParser.ArrayVarContext a) { cur = a.varDec(); continue; }
                if (cur instanceof SplcParser.ParenVarContext par) { cur = par.varDec(); continue; }
                throw new RuntimeException("Unsupported var declarator in func def");
            }
        }
    }

    /** 语句/表达式代码生成（基础子集） */
    private static class Codegen {
    private final IRBuilder ir;
    private final Symbols symbols;
    // param name -> type (for params of the current function)
    private final Map<String, IRType> paramTypes = new HashMap<>();
        private final FunctionBuilder fb;
        private BasicBlockBuilder bb;
    private final Map<String, IRValue> locals = new HashMap<>();
    private final Map<String, IRType> localTypes = new HashMap<>();

        private final Map<String, Integer> paramPointerDepths = new HashMap<>();

        Codegen(IRBuilder ir, Symbols symbols, FunctionBuilder fb, BasicBlockBuilder entry, List<Pair<String, IRType>> params, Map<String, Integer> paramPtrDepths, Map<String, IRType> declaredParamTypes) {
            this.ir = ir;
            this.symbols = symbols;
            this.fb = fb;
            this.bb = entry;
            // register parameter types
            if (declaredParamTypes != null && !declaredParamTypes.isEmpty()) {
                // prefer the declared (syntactic) parameter types for use during
                // codegen (so we can infer array element shapes). The actual
                // function ABI types were used when defining the function.
                this.paramTypes.putAll(declaredParamTypes);
            } else if (params != null) {
                for (var p : params) paramTypes.put(p.a, p.b);
            }
            if (paramPtrDepths != null) this.paramPointerDepths.putAll(paramPtrDepths);
            // 引用避免未使用告警
            this.ir.hashCode();
        }

        void emitStatement(SplcParser.StatementContext s) {
            // debug: log statement kind and runtime type
            System.err.println("[Codegen] emitStatement: class=" + s.getClass().getSimpleName() + " text='" + s.getText() + "'");
            if (s instanceof SplcParser.VarDecStmtContext vd) {
                IRType base = toIRType(vd.specifier());
                var decl = resolveVarDecl(base, vd.varDec());
                IRType ty = decl.arrayDims.isEmpty() ? decl.baseType : IRType.array(decl.baseType, decl.arrayDims.stream().mapToInt(Integer::intValue).toArray());
                String name = decl.name;
                IRValue addr = bb.alloca(ty, name + ".alloca");
                locals.put(name, addr);
                localTypes.put(name, ty);
                if (vd.expression() != null) {
                    IRValue v = evalExpr(vd.expression());
                    if (!v.type().typeEquals(ty) && v.type().isBoolean()) {
                        v = bb.zext(v, IRType.int32(), null);
                    }
                    // if storing integer 0 into a pointer-typed variable, use null pointer constant
                    if (ty.isPointer() && v.type().isInteger() && "0".equals(v.llvmName())) {
                        v = IRValue.constNull();
                    }
                    bb.store(addr, ty, v);
                }
                return;
            }
            if (s instanceof SplcParser.ReturnStmtContext rs) {
                IRValue v = evalExpr(rs.expression());
                if (!v.type().typeEquals(fb.getReturnType()) && v.type().isBoolean()) {
                    v = bb.zext(v, fb.getReturnType(), null);
                }
                bb.ret(v);
                return;
            }
            if (s instanceof SplcParser.ExprStmtContext es) {
                // try to handle plain function-call expression statements specially by parsing text
                String txt = s.getText().trim();
                // remove trailing semicolon if present
                if (txt.endsWith(";")) txt = txt.substring(0, txt.length() - 1);
                // match foo(...) pattern
                if (txt.matches("[A-Za-z_][A-Za-z0-9_]*\\s*\\(.*\\)")) {
                    int p = txt.indexOf('(');
                    String fname = txt.substring(0, p).trim();
                    String inside = txt.substring(p + 1, txt.lastIndexOf(')'));
                    List<IRValue> args = new ArrayList<>();
                    if (!inside.trim().isEmpty()) {
                        // Prefer using the existing parse tree children for arguments when available.
                        SplcParser.ExpressionContext ex = es.expression();
                        boolean usedChildren = true;
                        if (ex.getChildCount() >= 3) {
                            for (int i = 2; i < ex.getChildCount() - 1; i += 2) {
                                var child = ex.getChild(i);
                                if (child instanceof SplcParser.ExpressionContext ec) {
                                    IRValue v = evalExpr(ec);
                                    if (v.type().isBoolean()) v = bb.zext(v, IRType.int32(), null);
                                    args.add(v);
                                } else {
                                    usedChildren = false;
                                    break;
                                }
                            }
                        } else {
                            usedChildren = false;
                        }
                        if (!usedChildren) {
                            // fallback: naive comma-split parse (may fail on complex cases)
                            String[] parts = inside.split(",");
                            for (String part : parts) {
                                String a = part.trim();
                                try {
                                    CharStream cs = CharStreams.fromString(a);
                                    SplcLexer lx = new SplcLexer(cs);
                                    CommonTokenStream ts = new CommonTokenStream(lx);
                                    SplcParser pser = new SplcParser(ts);
                                    SplcParser.ExpressionContext argExpr = pser.expression();
                                    IRValue v = evalExpr(argExpr);
                                    if (v.type().isBoolean()) v = bb.zext(v, IRType.int32(), null);
                                    args.add(v);
                                } catch (Exception exx) {
                                    throw new RuntimeException("Failed to parse argument expression: " + a, exx);
                                }
                            }
                        }
                    }
                    // emit call and discard result
                    System.err.println("[Codegen] emitting call to " + fname + " with " + args.size() + " args (text-parse fallback)");
                    var sig = symbols.functions.getOrDefault(fname, new FuncSig(fname, IRType.int32(), List.of()));
                    bb.call(sig.ret(), fname, args, null);
                    return;
                }
                var ex = es.expression();
                // debug: inspect expression node children to understand function-call shape
                System.err.println("[Codegen] ExprStmt children count=" + ex.getChildCount());
                for (int i = 0; i < ex.getChildCount(); i++) {
                    var ch = ex.getChild(i);
                    System.err.println("  child[" + i + "] class=" + ch.getClass().getSimpleName() + " text='" + ch.getText() + "'");
                }
                evalExpr(ex); // 丢弃结果
                return;
            }
            if (s instanceof SplcParser.BlockStmtContext b) {
                // Enter a new lexical scope: snapshot locals and types so inner declarations
                // do not leak into outer scopes.
                Map<String, IRValue> localsSnap = new HashMap<>(locals);
                Map<String, IRType> typesSnap = new HashMap<>(localTypes);
                for (var st : b.statement()) emitStatement(st);
                // restore outer scope
                locals.clear(); locals.putAll(localsSnap);
                localTypes.clear(); localTypes.putAll(typesSnap);
                return;
            }
            if (s instanceof SplcParser.IfStmtContext is) {
                IRValue cond = evalExpr(is.expression());
                if (!cond.type().isBoolean()) {
                    IRValue zero = cond.type().isPointer() ? IRValue.constNull() : IRValue.consti32(0);
                    cond = bb.icmp(cond, LLVMIcmpPredicate.NotEquals, zero, null);
                }
                BasicBlockBuilder thenBB = fb.newBasicBlock("then");
                BasicBlockBuilder contBB = fb.newBasicBlock("cont");
                BasicBlockBuilder elseBB = null;
                if (is.statement().size() == 2) elseBB = fb.newBasicBlock("else");
                bb.condBr(cond, thenBB, elseBB == null ? contBB : elseBB);
                bb = thenBB;
                emitStatement(is.statement(0));
                if (!bb.hasTerminated()) bb.br(contBB);
                if (elseBB != null) {
                    bb = elseBB;
                    emitStatement(is.statement(1));
                    if (!bb.hasTerminated()) bb.br(contBB);
                }
                bb = contBB;
                return;
            }
            if (s instanceof SplcParser.WhileStmtContext ws) {
                BasicBlockBuilder condBB = fb.newBasicBlock("while.cond");
                BasicBlockBuilder bodyBB = fb.newBasicBlock("while.body");
                BasicBlockBuilder exitBB = fb.newBasicBlock("while.exit");
                bb.br(condBB);
                bb = condBB;
                IRValue cond = evalExpr(ws.expression());
                if (!cond.type().isBoolean()) {
                    IRValue zero = cond.type().isPointer() ? IRValue.constNull() : IRValue.consti32(0);
                    cond = bb.icmp(cond, LLVMIcmpPredicate.NotEquals, zero, null);
                }
                bb.condBr(cond, bodyBB, exitBB);
                bb = bodyBB;
                emitStatement(ws.statement());
                if (!bb.hasTerminated()) bb.br(condBB);
                bb = exitBB;
                return;
            }
            throw new RuntimeException("Unsupported statement");
        }

        IRValue evalExpr(SplcParser.ExpressionContext e) {
            // 基础：字面量、变量、二元算术、赋值、函数调用
            if (e.Number() != null) {
                int v = Integer.parseInt(e.Number().getText());
                return IRValue.consti32(v);
            }
            if (e.Char() != null) {
                int v = e.Char().getText().charAt(1);
                return IRValue.consti32(v);
            }
            // 复合的成员 / 数组访问作为右值：尝试通过 addressOfLvalueTyped 取得地址与类型并 load
            if ((e.DOT() != null || e.LBRACK() != null || e.ARROW() != null)) {
                var ap = addressOfLvalueTyped(e);
                IRValue addr = ap.a;
                IRType aty = ap.b;
                return bb.load(addr, aty, null);
            }

            if (e.Identifier() != null && e.LPAREN() == null) {
                String name = e.Identifier().getText();
                IRValue addr = resolveAddress(name);
                IRType ty = localTypes.getOrDefault(name, paramTypes.getOrDefault(name, symbols.globalTypes.get(name)));
                if (ty != null && ty.isPointer()) {
                    return bb.load(addr, IRType.pointer(), null);
                } else {
                    return bb.load(addr, IRType.int32(), null);
                }
            }
            // parenthesized expression like '(expr)'. Do NOT unwrap if this node is a function call
            // (Identifier '(' expr ')' form), otherwise we'll drop the callee identifier and return the
            // inner argument (bug: func0(readint()) -> readint()). Only unwrap when there's no Identifier.
            if (e.LPAREN() != null && e.RPAREN() != null && e.expression().size() == 1 && e.Identifier() == null) {
                return evalExpr(e.expression(0));
            }
            // 一元 +x / -x / !x
            if (e.PLUS() != null && e.expression().size() == 1) {
                return evalExpr(e.expression(0));
            }
            if (e.MINUS() != null && e.expression().size() == 1) {
                IRValue v = evalExpr(e.expression(0));
                // coerce boolean to i32 for numeric negation
                if (v.type().isBoolean()) v = bb.zext(v, IRType.int32(), null);
                if (!v.type().isInteger()) throw new RuntimeException("Unary - applied to non-integer: " + e.getText());
                return bb.sub(IRValue.consti32(0), v, null);
            }
            // 一元取地址 &x
            if (e.AMP() != null && e.expression().size() == 1) {
                var addrPair = addressOfLvalueTyped(e.expression(0));
                return addrPair.a; // address is a ptr
            }
            // 一元解引用 *p
            if (e.STAR() != null && e.expression().size() == 1) {
                SplcParser.ExpressionContext sub = e.expression(0);
                try {
                    var ap = addressOfLvalueTyped(sub);
                    // ap.a is address of the lvalue, ap.b is its type
                    if (ap.b.isPointer()) {
                        // load pointer value from variable, then load pointee
                        IRValue ptrVal = bb.load(ap.a, ap.b, null);
                        return bb.load(ptrVal, IRType.int32(), null);
                    } else {
                        // treat as loading value directly
                        return bb.load(ap.a, ap.b, null);
                    }
                } catch (RuntimeException ex) {
                    IRValue ptr = evalExpr(sub);
                    return bb.load(ptr, IRType.int32(), null);
                }
            }
            if (e.NOT() != null && e.expression().size() == 1) {
                IRValue v = evalExpr(e.expression(0));
                IRValue zero = v.type().isPointer() ? IRValue.constNull() : IRValue.consti32(0);
                IRValue isZero = bb.icmp(v, LLVMIcmpPredicate.Equals, zero, null);
                return isZero; // 布尔 i1
            }
            // debug: print structural info for complex expressions (temporary)
            if (e.getText().contains("&&") || e.getText().contains("||") || e.getText().contains("++") || e.getText().contains("--")) {
                System.err.println("[DBG] evalExpr text='" + e.getText() + "' childCount=" + e.getChildCount() + " exprCount=" + e.expression().size());
                for (int i = 0; i < e.getChildCount(); i++) {
                    var ch = e.getChild(i);
                    System.err.println("   child[" + i + "] class=" + ch.getClass().getSimpleName() + " text='" + ch.getText() + "'");
                }
                for (int i = 0; i < e.expression().size(); i++) {
                    System.err.println("   expr[" + i + "] text='" + e.expression(i).getText() + "'");
                }
            }

            // 函数调用：Identifier '(' args ')'
            // Note: RPAR may not be directly present for non-empty arg lists in the parse tree,
            // so only check for LPAREN presence.
            // debug: expression tokens for call detection
            System.err.println("[Codegen] evalExpr: class=" + e.getClass().getSimpleName() + " expr='" + e.getText() + "' Identifier=" + (e.Identifier()!=null) + " LPAREN=" + (e.LPAREN()!=null));
            // Some call forms appear as: Identifier '(' expr (',' expr)* ')', i.e. children [id, '(', expr, ',', expr, ... , ')']
            if (e.getChildCount() >= 2 && e.getChild(0).getText().matches("[A-Za-z_][A-Za-z0-9_]*") && "(".equals(e.getChild(1).getText())) {
                String fname = e.getChild(0).getText();
                // build args from child expression nodes at positions 2,4,6,... until before last
                List<IRValue> args = new ArrayList<>();
                for (int i = 2; i < e.getChildCount() - 1; i += 2) {
                    var child = e.getChild(i);
                    if (child instanceof SplcParser.ExpressionContext ec) {
                        IRValue v = evalExpr(ec);
                        if (v.type().isBoolean()) v = bb.zext(v, IRType.int32(), null);
                        args.add(v);
                    } else {
                        break;
                    }
                }
                System.err.println("[Codegen] emitting call to " + fname + " with " + args.size() + " args (alt form)");
                var sig = symbols.functions.getOrDefault(fname, new FuncSig(fname, IRType.int32(), List.of()));
                return bb.call(sig.ret(), fname, args, null);
            }
            if (e.Identifier() != null && e.LPAREN() != null) {
                String fname = e.Identifier().getText();
                var sig = symbols.functions.getOrDefault(fname, new FuncSig(fname, IRType.int32(), List.of()));
                List<IRValue> args = new ArrayList<>();
                int n = 0;
                while (true) {
                    try {
                        var arg = e.expression(n);
                        if (arg == null) break;
                        IRValue v = evalExpr(arg);
                        if (v.type().isBoolean()) v = bb.zext(v, IRType.int32(), null);
                        args.add(v);
                        n++;
                    } catch (Exception ex) {
                        break;
                    }
                }
                // debug: log function calls being emitted
                System.err.println("[Codegen] emitting call to " + fname + " with " + args.size() + " args");
                return bb.call(sig.ret(), fname, args, null);
            }
            // (removed brittle array text-based rvalue handling) -- now handled via addressOfLvalue above
            // 赋值：lhs '=' rhs （支持变量与单层数组元素）
            if (e.ASSIGN() != null && e.expression().size() == 2) {
                SplcParser.ExpressionContext lhs = e.expression(0);
                SplcParser.ExpressionContext rhs = e.expression(1);
                var lhsPair = addressOfLvalueTyped(lhs);
                IRValue addr = lhsPair.a;
                IRType lhsTy = lhsPair.b;
                IRValue val = evalExpr(rhs);
                if (val.type().isBoolean() && lhsTy.isInteger()) val = bb.zext(val, IRType.int32(), null);
                // if assigning integer 0 to a pointer lvalue, convert to null ptr constant
                if (lhsTy.isPointer() && val.type().isInteger() && "0".equals(val.llvmName())) {
                    val = IRValue.constNull();
                }
                if (!addr.type().isPointer()) {
                    throw new RuntimeException("Store target is not a pointer. LHS=" + lhs.getText() + ", addr.type=" + addr.type().llvmName());
                }
                bb.store(addr, lhsTy, val);
                return val;
            }
            // 前缀/后缀 ++ / -- ：变量或数组元素
            if (e.INC() != null && e.expression().size() == 1) {
                var pair = addressOfLvalueTyped(e.expression(0));
                IRValue addr = pair.a; IRType ety = pair.b;
                IRValue old = bb.load(addr, ety, null);
                IRValue neu;
                if (ety.isPointer()) {
                    // pointer arithmetic: assume pointer to int32 for basic tests
                    // Use single-index GEP on the element type (i32) instead of
                    // constructing a zero-length array type. This produces
                    // getelementptr i32, ptr <p>, i32 1 which matches runtime
                    // pointers that point to elements (i32*).
                    neu = bb.gep(old, IRType.int32(), IRValue.consti32(1), null);
                } else {
                    neu = bb.add(old, IRValue.consti32(1), null);
                }
                bb.store(addr, ety, neu);
                String text = e.getText();
                return text.startsWith("++") ? neu : old;
            }
            if (e.DEC() != null && e.expression().size() == 1) {
                var pair = addressOfLvalueTyped(e.expression(0));
                IRValue addr = pair.a; IRType ety = pair.b;
                IRValue old = bb.load(addr, ety, null);
                IRValue neu;
                if (ety.isPointer()) {
                    // decrement pointer: use single-index GEP on element type
                    neu = bb.gep(old, IRType.int32(), IRValue.consti32(-1), null);
                } else {
                    neu = bb.sub(old, IRValue.consti32(1), null);
                }
                bb.store(addr, ety, neu);
                String text = e.getText();
                return text.startsWith("--") ? neu : old;
            }
            // 二元：+ - * / %、比较生成 i1，以及逻辑与/或
            if (e.expression().size() == 2) {
                // Handle logical AND/OR with short-circuit first (must not evaluate RHS eagerly)
                if (e.AND() != null) {
                    IRValue a = evalExpr(e.expression(0));
                    IRValue aBool = a.type().isBoolean() ? a : bb.icmp(a, LLVMIcmpPredicate.NotEquals, (a.type().isPointer() ? IRValue.constNull() : IRValue.consti32(0)), null);
                    var rhsBB = fb.newBasicBlock("and.rhs");
                    var exitBB = fb.newBasicBlock("and.exit");
                    IRValue resAddr = bb.alloca(IRType.int32(), "and.tmp");
                    bb.store(resAddr, IRType.int32(), IRValue.consti32(0));
                    bb.condBr(aBool, rhsBB, exitBB);
                    bb = rhsBB;
                    IRValue b = evalExpr(e.expression(1));
                    IRValue bBool = b.type().isBoolean() ? b : bb.icmp(b, LLVMIcmpPredicate.NotEquals, (b.type().isPointer() ? IRValue.constNull() : IRValue.consti32(0)), null);
                    IRValue bInt = bb.zext(bBool, IRType.int32(), null);
                    bb.store(resAddr, IRType.int32(), bInt);
                    if (!bb.hasTerminated()) bb.br(exitBB);
                    bb = exitBB;
                    IRValue resInt = bb.load(resAddr, IRType.int32(), null);
                    return bb.icmp(resInt, LLVMIcmpPredicate.NotEquals, IRValue.consti32(0), null);
                }
                if (e.OR() != null) {
                    IRValue a = evalExpr(e.expression(0));
                    IRValue aBool = a.type().isBoolean() ? a : bb.icmp(a, LLVMIcmpPredicate.NotEquals, (a.type().isPointer() ? IRValue.constNull() : IRValue.consti32(0)), null);
                    var thenBB = fb.newBasicBlock("or.then");
                    var rhsBB = fb.newBasicBlock("or.rhs");
                    var exitBB = fb.newBasicBlock("or.exit");
                    IRValue resAddr = bb.alloca(IRType.int32(), "or.tmp");
                    bb.store(resAddr, IRType.int32(), IRValue.consti32(0));
                    bb.condBr(aBool, thenBB, rhsBB);
                    bb = thenBB;
                    bb.store(resAddr, IRType.int32(), IRValue.consti32(1));
                    if (!bb.hasTerminated()) bb.br(exitBB);
                    bb = rhsBB;
                    IRValue b = evalExpr(e.expression(1));
                    IRValue bBool = b.type().isBoolean() ? b : bb.icmp(b, LLVMIcmpPredicate.NotEquals, (b.type().isPointer() ? IRValue.constNull() : IRValue.consti32(0)), null);
                    IRValue bInt = bb.zext(bBool, IRType.int32(), null);
                    bb.store(resAddr, IRType.int32(), bInt);
                    if (!bb.hasTerminated()) bb.br(exitBB);
                    bb = exitBB;
                    IRValue resInt = bb.load(resAddr, IRType.int32(), null);
                    return bb.icmp(resInt, LLVMIcmpPredicate.NotEquals, IRValue.consti32(0), null);
                }

                // Other binary operators: evaluate left then right as needed
                IRValue a = evalExpr(e.expression(0));
                IRValue b = evalExpr(e.expression(1));
                if (e.PLUS() != null) {
                    // pointer + int -> gep (assume int32 element); int + pointer likewise
                    if (a.type().isPointer() && b.type().isInteger()) {
                        // pointer + int: GEP on element type
                        return bb.gep(a, IRType.int32(), b, null);
                    }
                    if (b.type().isPointer() && a.type().isInteger()) {
                        return bb.gep(b, IRType.int32(), a, null);
                    }
                    return bb.add(a, b, null);
                }
                if (e.MINUS() != null) {
                    // pointer - int -> gep with negative index
                    if (a.type().isPointer() && b.type().isInteger()) {
                        IRValue bi = b;
                        if (bi.type().isBoolean()) bi = bb.zext(bi, IRType.int32(), null);
                        IRValue neg = bb.sub(IRValue.consti32(0), bi, null);
                        return bb.gep(a, IRType.int32(), neg, null);
                    }
                    // int - pointer is invalid
                    if (a.type().isInteger() && b.type().isPointer()) {
                        throw new RuntimeException("Invalid operands to - : int - pointer");
                    }
                    // pointer - pointer (difference) not implemented
                    if (a.type().isPointer() && b.type().isPointer()) {
                        throw new RuntimeException("Pointer - pointer not supported");
                    }
                    return bb.sub(a, b, null);
                }
                if (e.STAR() != null) return bb.mul(a, b, null);
                if (e.DIV() != null) return bb.div(a, b, null);
                if (e.MOD() != null) return bb.rem(a, b, null);
                if (e.LT() != null || e.LE() != null || e.GT() != null || e.GE() != null) {
                    // relational operators only valid for integers; coerce booleans to int
                    if (a.type().isBoolean()) a = bb.zext(a, IRType.int32(), null);
                    if (b.type().isBoolean()) b = bb.zext(b, IRType.int32(), null);
                    if (!a.type().isInteger() || !b.type().isInteger())
                        throw new RuntimeException("Invalid operands to relational operator: " + e.getText());
                    if (e.LT() != null) return bb.icmp(a, LLVMIcmpPredicate.SignedLT, b, null);
                    if (e.LE() != null) return bb.icmp(a, LLVMIcmpPredicate.SignedLE, b, null);
                    if (e.GT() != null) return bb.icmp(a, LLVMIcmpPredicate.SignedGT, b, null);
                    if (e.GE() != null) return bb.icmp(a, LLVMIcmpPredicate.SignedGE, b, null);
                }
                if (e.EQ() != null || e.NEQ() != null) {
                    // equality: allow ints, bools, and pointers. Try reasonable coercions.
                    if (a.type().isBoolean()) a = bb.zext(a, IRType.int32(), null);
                    if (b.type().isBoolean()) b = bb.zext(b, IRType.int32(), null);
                    // pointer vs integer (only allow comparison with 0)
                    if (a.type().isPointer() && b.type().isInteger() && b.llvmName().equals("0")) {
                        IRValue nul = IRValue.constNull();
                        return bb.icmp(a, e.EQ() != null ? LLVMIcmpPredicate.Equals : LLVMIcmpPredicate.NotEquals, nul, null);
                    }
                    if (b.type().isPointer() && a.type().isInteger() && a.llvmName().equals("0")) {
                        IRValue nul = IRValue.constNull();
                        return bb.icmp(b, e.EQ() != null ? LLVMIcmpPredicate.Equals : LLVMIcmpPredicate.NotEquals, nul, null);
                    }
                    if (!a.type().typeEquals(b.type()))
                        throw new RuntimeException("Incompatible types for equality: " + e.getText());
                    if (e.EQ() != null) return bb.icmp(a, LLVMIcmpPredicate.Equals, b, null);
                    return bb.icmp(a, LLVMIcmpPredicate.NotEquals, b, null);
                }
            }
            throw new RuntimeException("Unsupported expression: " + e.getText());
        }

        private IRType toIRType(SplcParser.SpecifierContext spec) {
            if (spec instanceof SplcParser.IntSpecContext) return IRType.int32();
            if (spec instanceof SplcParser.CharSpecContext) return IRType.int32();
            if (spec instanceof SplcParser.StructDeclSpecContext s) return IRType.structure(s.Identifier().getText());
            if (spec instanceof SplcParser.FullStructSpecContext f) return IRType.structure(f.Identifier().getText());
            throw new RuntimeException("Only int/char/struct supported in basic codegen");
        }

        private static class VarDecl {
            String name;
            IRType baseType;
            List<Integer> arrayDims = new ArrayList<>();
        }

        private VarDecl resolveVarDecl(IRType baseType, SplcParser.VarDecContext vd) {
            VarDecl out = new VarDecl();
            out.baseType = baseType;
            SplcParser.VarDecContext cur = vd;
            while (true) {
                if (cur instanceof SplcParser.SimpleVarContext s) {
                    out.name = s.Identifier().getText();
                    break;
                } else if (cur instanceof SplcParser.PointerVarContext p) {
                    out.baseType = IRType.pointer();
                    cur = p.varDec();
                } else if (cur instanceof SplcParser.ArrayVarContext a) {
                    int size = Integer.parseInt(a.Number().getText());
                    out.arrayDims.add(size);
                    cur = a.varDec();
                } else if (cur instanceof SplcParser.ParenVarContext par) {
                    cur = par.varDec();
                } else {
                    throw new RuntimeException("Unsupported var declarator");
                }
            }
            Collections.reverse(out.arrayDims);
            return out;
        }

        private Pair<IRValue, IRType> addressOfLvalueTyped(SplcParser.ExpressionContext lval) {
            // unwrap parenthesized lvalues like '(expr)'
            if (lval.LPAREN() != null && lval.RPAREN() != null && lval.expression().size() == 1) {
                var inner = lval.expression(0);
                try {
                    return addressOfLvalueTyped(inner);
                } catch (RuntimeException ex) {
                    // inner is not a plain lvalue: materialize the rvalue into a temporary
                    // alloca and return its address. This ensures callers expecting an
                    // address-of-storage (so they can load/store) work consistently and
                    // avoids attempting to load from a raw pointer value.
                    IRValue v = evalExpr(inner);
                    IRType ty = v.type();
                    IRValue tmp = bb.alloca(ty, "tmp.lval");
                    bb.store(tmp, ty, v);
                    return new Pair<>(tmp, ty);
                }
            }
            // simple identifier
            if (lval.Identifier() != null && lval.LBRACK() == null && lval.DOT() == null && lval.ARROW() == null) {
                String name = lval.Identifier().getText();
                IRValue addr = resolveAddress(name);
                IRType ty = localTypes.getOrDefault(name, paramTypes.getOrDefault(name, symbols.globalTypes.get(name)));
                if (ty == null) throw new RuntimeException("Unknown variable: " + name);
                return new Pair<>(addr, ty);
            }

            // struct member access: base.member
            if (lval.DOT() != null && lval.expression().size() == 1 && lval.Identifier() != null) {
                var baseExpr = lval.expression(0);
                String member = lval.Identifier().getText();
                // get base address and type recursively
                var basePair = addressOfLvalueTyped(baseExpr);
                IRValue baseAddr = basePair.a;
                IRType baseTy = basePair.b;
                // if baseTy is array, element type is arrayNext
                if (baseTy.isArray()) baseTy = baseTy.arrayNext();
                // If the resolved base type is a pointer (e.g. we materialized a pointer
                // rvalue into a temporary alloca), load the pointer value and use that
                // as the GEP base. Otherwise, baseAddr itself should be a pointer to
                // the aggregate.
                IRValue gepBase = baseAddr;
                if (baseTy.isPointer()) {
                    // load the pointer value stored at baseAddr
                    gepBase = bb.load(baseAddr, IRType.pointer(), null);
                    // the pointee type may be a structure; we will attempt to discover
                    // the struct name below when resolving the member index
                }
                if (!baseTy.isStructure() && !baseTy.isPointer()) throw new RuntimeException("Base is not a structure: " + baseExpr.getText());
                // resolve struct name (if baseTy is pointer, try to infer by scanning structs)
                String stName = null;
                IRType fieldType = null;
                int idx = -1;
                if (baseTy.isStructure()) {
                    stName = baseTy.structureName();
                    var fields = symbols.structs.get(stName);
                    if (fields == null) throw new RuntimeException("Unknown struct: " + stName);
                    for (int i = 0; i < fields.size(); i++) {
                        if (fields.get(i).a.equals(member)) { idx = i; fieldType = fields.get(i).b; break; }
                    }
                    if (idx < 0) throw new RuntimeException("Unknown member '" + member + "' in struct " + stName);
                } else {
                    // baseTy is pointer: brute-force search struct definitions for the member
                    for (var en : symbols.structs.entrySet()) {
                        var fields = en.getValue();
                        for (int i = 0; i < fields.size(); i++) {
                            if (fields.get(i).a.equals(member)) { stName = en.getKey(); fieldType = fields.get(i).b; idx = i; break; }
                        }
                        if (stName != null) break;
                    }
                    if (stName == null) throw new RuntimeException("Unknown member '" + member + "' in any struct");
                }
                IRType structTy = IRType.structure(stName);
                IRValue memPtr = bb.gep(gepBase, structTy, 0, IRValue.consti32(idx), null);
                return new Pair<>(memPtr, fieldType);
            }

            // pointer member access: base->member  (base evaluates to pointer to struct)
            if (lval.ARROW() != null && lval.expression().size() == 1 && lval.Identifier() != null) {
                var baseExpr = lval.expression(0);
                String member = lval.Identifier().getText();
                // try to get address of baseExpr; if not possible, evaluate expr to pointer
                IRValue ptrVal;
                try {
                    var bp = addressOfLvalueTyped(baseExpr);
                    IRValue baseAddr = bp.a; IRType baseTy = bp.b;
                    // If addressOfLvalueTyped returned an address-of-storage for a variable that
                    // itself holds a pointer (e.g. variable `p` of type structX*), we need to
                    // load that pointer from storage. But if the base expression already
                    // yielded a pointer value (for example `&s0`), we should use it directly
                    // without an extra load. Use a best-effort heuristic: try to extract an
                    // identifier from the base expression; if one exists and its declared
                    // type is pointer, perform a load. Otherwise assume baseAddr is already
                    // the desired pointer value.
                    if (baseTy.isPointer() || baseTy.isArray()) {
                        // baseAddr is an address-of-storage that holds a pointer
                        // value; load it to obtain the pointer to the struct.
                        ptrVal = bb.load(baseAddr, IRType.pointer(), null);
                    } else {
                        // baseAddr itself may be pointer value
                        ptrVal = baseAddr;
                    }
                } catch (RuntimeException ex) {
                    ptrVal = evalExpr(baseExpr);
                }
                // assume pointer points to struct; need struct name from types if possible
                // try to get struct name from baseExpr's declared type
                IRType declared = localTypes.getOrDefault(baseExpr.getText(), paramTypes.getOrDefault(baseExpr.getText(), symbols.globalTypes.get(baseExpr.getText())));
                if (declared != null && declared.isPointer()) {
                    // no info about pointee in IRType.pointer(), try to fallback to struct by name lookup in symbols
                }
                // brute-force: search all struct types for member name (pick first match)
                String foundStruct = null; IRType fieldType = null; int idx = -1;
                for (var en : symbols.structs.entrySet()) {
                    var fields = en.getValue();
                    for (int i = 0; i < fields.size(); i++) {
                        if (fields.get(i).a.equals(member)) { foundStruct = en.getKey(); fieldType = fields.get(i).b; idx = i; break; }
                    }
                    if (foundStruct != null) break;
                }
                if (foundStruct == null) throw new RuntimeException("Unknown member '" + member + "' in any struct");
                IRType stTy = IRType.structure(foundStruct);
                IRValue memPtr = bb.gep(ptrVal, stTy, 0, IRValue.consti32(idx), null);
                return new Pair<>(memPtr, fieldType);
            }

            // pointer dereference lvalue: *p
            if (lval.STAR() != null && lval.expression().size() == 1) {
                var inner = lval.expression(0);
                try {
                    var bp = addressOfLvalueTyped(inner);
                    IRValue addrOfPtr = bp.a; IRType addrType = bp.b;
                    if (addrType.isPointer()) {
                        IRValue ptrVal = bb.load(addrOfPtr, IRType.pointer(), null);
                        // try to decide whether this is pointer-to-pointer (-> return pointer)
                        // or pointer-to-int (-> return i32). For function parameters we have ptr-depth info.
                        if (inner.Identifier() != null) {
                            String nm = inner.Identifier().getText();
                            int depth = paramPointerDepths.getOrDefault(nm, 1);
                            if (depth >= 2) return new Pair<>(ptrVal, IRType.pointer());
                        }
                        // default: assume pointee is int
                        return new Pair<>(ptrVal, IRType.int32());
                    }
                } catch (RuntimeException ex) {
                    // fallback
                }
                IRValue ptr = evalExpr(inner);
                return new Pair<>(ptr, IRType.int32());
            }

            // array indexing: base[index]
            if (lval.LBRACK() != null && lval.expression().size() >= 1) {
                // grammar: expression '[' expression ']'
                SplcParser.ExpressionContext baseExpr = lval.expression(0);
                SplcParser.ExpressionContext idxExpr = lval.expression(1);
                // get base address & type; if base is identifier (array variable) addressOfLvalueTyped will return its addr and array type
                var basePair = addressOfLvalueTyped(baseExpr);
                IRValue basePtr = basePair.a;
                IRType baseTy = basePair.b;
                // if baseTy is pointer to element (i.e., previous indexing returned element type), handle accordingly
                IRValue index = evalExpr(idxExpr);
                if (baseTy.isArray()) {
                    // basePtr points to the array; gep with index
                    IRValue elemPtr = bb.gep(basePtr, baseTy, 0, index, null);
                    IRType elemType = baseTy.arrayNext();
                    return new Pair<>(elemPtr, elemType);
                } else {
                    // baseTy might already be element type (previous indexing), or it might be an untyped pointer
                    // If it's a raw pointer, assume it points to i32 for these tests.
                    if (baseTy.isPointer()) {
                        // basePtr is the address of a pointer-valued variable (e.g. a param or local holding a pointer);
                        // load the pointer value first, then GEP on the pointee.
                        IRValue loadedPtr = bb.load(basePtr, IRType.pointer(), null);
                        // try to deduce the pointee/element type from the base expression's declared type
                        IRType elemType = null;
                        String maybeIdent = tryExtractIdent(baseExpr);
                        if (maybeIdent != null) {
                            IRType declared = localTypes.getOrDefault(maybeIdent, paramTypes.getOrDefault(maybeIdent, symbols.globalTypes.get(maybeIdent)));
                            if (declared != null) {
                                if (declared.isArray()) elemType = declared.arrayNext();
                                else if (declared.isStructure()) elemType = declared;
                                else if (declared.isPointer()) {
                                    // pointer declared type -> unknown pointee; leave elemType null to fallback
                                }
                            }
                        }
                        if (elemType == null) elemType = IRType.int32();
                        // When we have a runtime pointer value (loadedPtr) that points to
                        // elements (e.g. i32*), perform a single-index GEP on the element
                        // type. This yields correct element pointers like `getelementptr i32, ptr %p, i32 %idx`.
                        IRValue elemPtr = bb.gep(loadedPtr, elemType, index, null);
                        return new Pair<>(elemPtr, elemType);
                    }
                    // Avoid creating a zero-sized array type here; use a 1-sized
                    // wrapper so the generated GEP isn't printed as `[0 x T]` which
                    // can lead to invalid addressing in the runtime. The size
                    // doesn't affect address computation semantics for GEP indices
                    // used here (we only need an aggregate shape), so 1 is safe.
                    IRType arrTy = IRType.array(baseTy, 1);
                    IRValue elemPtr = bb.gep(basePtr, arrTy, 0, index, null);
                    IRType elemType = baseTy;
                    return new Pair<>(elemPtr, elemType);
                }
            }

            throw new RuntimeException("Unsupported lvalue: " + lval.getText());
        }

        private IRValue addressOfLvalue(SplcParser.ExpressionContext lval) {
            return addressOfLvalueTyped(lval).a;
        }

        private IRValue resolveAddress(String name) {
            if (locals.containsKey(name)) return locals.get(name);
            IRValue p = fb.param(name);
            if (p != null) return p;
            if (symbols.globals.containsKey(name)) return symbols.globals.get(name);
            throw new RuntimeException("Unknown variable: " + name);
        }

        // helper: try to extract a single identifier name from possibly-wrapped expressions like
        // Identifier, (Identifier), &Identifier, or ( & Identifier ) etc. Returns null if none found.
        private String tryExtractIdent(SplcParser.ExpressionContext e) {
            if (e == null) return null;
            if (e.Identifier() != null) return e.Identifier().getText();
            // parenthesized
            if (e.LPAREN() != null && e.RPAREN() != null && e.expression().size() == 1) {
                return tryExtractIdent(e.expression(0));
            }
            // address-of: &id
            if (e.AMP() != null && e.expression().size() == 1) {
                return tryExtractIdent(e.expression(0));
            }
                // array indexing: id[...] -> try to extract the base identifier
                if (e.LBRACK() != null && e.expression().size() >= 1) {
                    return tryExtractIdent(e.expression(0));
                }
            // simple deref or other wrappers may hide identifier, but we don't attempt deeper heuristics here
            return null;
        }
    }
}
