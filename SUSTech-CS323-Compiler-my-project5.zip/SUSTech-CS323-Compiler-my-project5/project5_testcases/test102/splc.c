int readint();
int writeint(int out);
int setseed(int seed);
int getrand();
int assert_eq(int where, int given, int expected);

int main0() {
    int n = 5;
    int arr[5];
    int i = 0;

    while (i < n) {
        arr[i] = readint();
        i = i + 1;
    }

    int sum = 0;
    int mx = arr[0];
    int mn = arr[0];

    i = 0;
    while (i < n) {
        sum = sum + arr[i];
        if (arr[i] > mx) mx = arr[i];
        if (arr[i] < mn) mn = arr[i];
        i = i + 1;
    }

    writeint(sum);
    writeint(mx);
    writeint(mn);
    return 0;
}
