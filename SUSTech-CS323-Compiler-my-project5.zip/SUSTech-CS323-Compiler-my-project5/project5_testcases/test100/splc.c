int readint();
int writeint(int out);
int setseed(int seed);
int getrand();
int assert_eq(int where, int given, int expected);

int main0() {
    int a = readint();
    int b = readint();
    int c = a + b;
    int d = a * b;
    int e = a - b;
    int f = 0;
    int g = a % b; /* b 在测试输入中保证非 0 */

    if (c > 100) {
        f = c - 100;
    } else {
        f = 100 - c;
    }

    writeint(c);
    writeint(d);
    writeint(e);
    writeint(g);
    writeint(f);
    return 0;
}
