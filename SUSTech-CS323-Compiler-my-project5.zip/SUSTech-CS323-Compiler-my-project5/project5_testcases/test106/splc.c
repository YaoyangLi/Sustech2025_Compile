int readint();
int writeint(int out);
int setseed(int seed);
int getrand();
int assert_eq(int where, int given, int expected);

struct Point {
    int x;
    int y;
};

int manhattan(struct Point p) {
    int ax = p.x;
    int ay = p.y;
    if (ax < 0) ax = 0 - ax;
    if (ay < 0) ay = 0 - ay;
    return ax + ay;
}

int main0() {
    struct Point ps[3];
    int i = 0;

    while (i < 3) {
        ps[i].x = readint();
        ps[i].y = readint();
        i = i + 1;
    }

    int sx = ps[0].x + ps[1].x + ps[2].x;

    writeint(manhattan(ps[0]));
    writeint(manhattan(ps[1]));
    writeint(manhattan(ps[2]));
    writeint(sx);
    return 0;
}
