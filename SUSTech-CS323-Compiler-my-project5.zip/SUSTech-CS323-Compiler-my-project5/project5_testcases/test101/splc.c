int readint();
int writeint(int out);
int setseed(int seed);
int getrand();
int assert_eq(int where, int given, int expected);

int gcd(int x, int y) {
    while (y != 0) {
        int t = x % y;
        x = y;
        y = t;
    }
    return x;
}

int main0() {
    int a = readint();
    int b = readint();
    if (a < 0) a = 0 - a;
    if (b < 0) b = 0 - b;
    writeint(gcd(a, b));
    return 0;
}
