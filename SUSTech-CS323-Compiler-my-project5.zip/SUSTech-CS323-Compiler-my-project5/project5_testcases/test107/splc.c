int readint();
int writeint(int out);
int setseed(int seed);
int getrand();
int assert_eq(int where, int given, int expected);

struct Pair {
    int a;
    int b;
};
struct Triple {
    struct Pair p;
    int c;
};

int sum_triple(struct Triple t) {
    return t.p.a + t.p.b + t.c;
}

int main0() {
    struct Triple t1;
    struct Triple t2;

    t1.p.a = readint();
    t1.p.b = readint();
    t1.c = readint();

    t2 = t1;

    t2.p.a = t2.p.a + 1;
    t2.p.b = t2.p.b + 2;
    t2.c = t2.c + 3;

    writeint(sum_triple(t1));
    writeint(sum_triple(t2));
    writeint(t2.p.a - t1.p.a);
    return 0;
}
