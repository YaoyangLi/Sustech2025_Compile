int readint();
int writeint(int out);
int setseed(int seed);
int getrand();
int assert_eq(int where, int given, int expected);

int main0() {
    int a = readint();
    int b = readint();
    int c = readint();

    int ab = (a < b);
    int bc = (b < c);
    int ca = (c < a);
    int score = ab + bc + ca;

    int ans = 0;
    if (score == 0) {
        ans = a + b + c;
    } else {
        if (score == 3) {
            ans = a * b * c;
        } else {
            ans = a + b - c;
        }
    }

    writeint(score);
    writeint(ans);
    return 0;
}
