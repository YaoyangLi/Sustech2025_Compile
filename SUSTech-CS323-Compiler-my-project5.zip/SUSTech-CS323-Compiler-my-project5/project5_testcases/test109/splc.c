int readint();
int writeint(int out);
int setseed(int seed);
int getrand();
int assert_eq(int where, int given, int expected);

struct Node {
    int v;
    struct Node* next;
};

int main0() {
    struct Node n1;
    struct Node n2;
    struct Node n3;

    n1.v = readint();
    n2.v = readint();
    n3.v = readint();

    n1.next = &n2;
    n2.next = &n3;
    n3.next = (struct Node*)0;

    int sum = 0;
    struct Node* cur = &n1;
    while (cur != (struct Node*)0) {
        sum = sum + cur->v;
        cur = cur->next;
    }

    writeint(sum);
    return 0;
}
