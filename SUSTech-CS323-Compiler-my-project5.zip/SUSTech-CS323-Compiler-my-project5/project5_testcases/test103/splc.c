int readint();
int writeint(int out);
int setseed(int seed);
int getrand();
int assert_eq(int where, int given, int expected);

int fact(int n) {
    if (n <= 1) return 1;
    return n * fact(n - 1);
}

int fib_iter(int n) {
    int a = 0;
    int b = 1;
    int i = 0;
    while (i < n) {
        int t = a + b;
        a = b;
        b = t;
        i = i + 1;
    }
    return a;
}

int main0() {
    int n = readint();
    int m = readint();
    writeint(fact(n));
    writeint(fib_iter(m));
    return 0;
}
