int readint();
int writeint(int out);
int setseed(int seed);
int getrand();
int assert_eq(int where, int given, int expected);

struct Pair {
    int x;
    int y;
};

void adjust(struct Pair* p, int k) {
    /* 通过结构体指针修改字段：既覆盖结构体，又覆盖指针扩展 */
    p->x = p->x + k;
    p->y = p->y - k;
}

void swap_int(int* a, int* b) {
    /* 通过 int 指针交换两个整数 */
    int t = *a;
    *a = *b;
    *b = t;
}

int main0() {
    /* 输入 5 个整数：
       x, y：结构体初值
       k：调整量
       u, v：用于数组求和（测试指针算术 ap + 1） */
    int x = readint();
    int y = readint();
    int k = readint();
    int u = readint();
    int v = readint();

    struct Pair p;
    p.x = x;
    p.y = y;

    struct Pair* pp = &p;
    adjust(pp, k);

    /* 小数组 + 指针算术：确保 (ap + 1) 仍在数组范围内 */
    int arr[2];
    arr[0] = u;
    arr[1] = v;
    int* ap = &arr[0];
    int sum = *(ap) + *(ap + 1);

    /* 通过结构体指针取字段地址，进一步覆盖 & 与 -> 的组合用法 */
    swap_int(&(pp->x), &(pp->y));

    writeint(pp->x);
    writeint(pp->y);
    writeint(sum);
    return 0;
}
