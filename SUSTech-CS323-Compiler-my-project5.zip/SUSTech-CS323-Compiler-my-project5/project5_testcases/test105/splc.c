int readint();
int writeint(int out);
int setseed(int seed);
int getrand();
int assert_eq(int where, int given, int expected);

int main0() {
    int mat[2][3];
    int i = 0;
    int j = 0;

    i = 0;
    while (i < 2) {
        j = 0;
        while (j < 3) {
            mat[i][j] = readint();
            j = j + 1;
        }
        i = i + 1;
    }

    int r0 = mat[0][0] + mat[0][1] + mat[0][2];
    int r1 = mat[1][0] + mat[1][1] + mat[1][2];
    int diag = mat[0][0] + mat[1][1];

    writeint(r0);
    writeint(r1);
    writeint(diag);
    return 0;
}
