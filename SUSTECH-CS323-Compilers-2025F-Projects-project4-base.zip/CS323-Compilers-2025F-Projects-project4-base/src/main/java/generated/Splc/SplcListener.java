// Generated from Splc.g4 by ANTLR 4.13.2
package generated.Splc;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link SplcParser}.
 */
public interface SplcListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link SplcParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(SplcParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link SplcParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(SplcParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FuncDef}
	 * labeled alternative in {@link SplcParser#globalDef}.
	 * @param ctx the parse tree
	 */
	void enterFuncDef(SplcParser.FuncDefContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FuncDef}
	 * labeled alternative in {@link SplcParser#globalDef}.
	 * @param ctx the parse tree
	 */
	void exitFuncDef(SplcParser.FuncDefContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FuncDecl}
	 * labeled alternative in {@link SplcParser#globalDef}.
	 * @param ctx the parse tree
	 */
	void enterFuncDecl(SplcParser.FuncDeclContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FuncDecl}
	 * labeled alternative in {@link SplcParser#globalDef}.
	 * @param ctx the parse tree
	 */
	void exitFuncDecl(SplcParser.FuncDeclContext ctx);
	/**
	 * Enter a parse tree produced by the {@code GlobalVarDef}
	 * labeled alternative in {@link SplcParser#globalDef}.
	 * @param ctx the parse tree
	 */
	void enterGlobalVarDef(SplcParser.GlobalVarDefContext ctx);
	/**
	 * Exit a parse tree produced by the {@code GlobalVarDef}
	 * labeled alternative in {@link SplcParser#globalDef}.
	 * @param ctx the parse tree
	 */
	void exitGlobalVarDef(SplcParser.GlobalVarDefContext ctx);
	/**
	 * Enter a parse tree produced by the {@code GlobalStructDecl}
	 * labeled alternative in {@link SplcParser#globalDef}.
	 * @param ctx the parse tree
	 */
	void enterGlobalStructDecl(SplcParser.GlobalStructDeclContext ctx);
	/**
	 * Exit a parse tree produced by the {@code GlobalStructDecl}
	 * labeled alternative in {@link SplcParser#globalDef}.
	 * @param ctx the parse tree
	 */
	void exitGlobalStructDecl(SplcParser.GlobalStructDeclContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IntSpec}
	 * labeled alternative in {@link SplcParser#specifier}.
	 * @param ctx the parse tree
	 */
	void enterIntSpec(SplcParser.IntSpecContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IntSpec}
	 * labeled alternative in {@link SplcParser#specifier}.
	 * @param ctx the parse tree
	 */
	void exitIntSpec(SplcParser.IntSpecContext ctx);
	/**
	 * Enter a parse tree produced by the {@code CharSpec}
	 * labeled alternative in {@link SplcParser#specifier}.
	 * @param ctx the parse tree
	 */
	void enterCharSpec(SplcParser.CharSpecContext ctx);
	/**
	 * Exit a parse tree produced by the {@code CharSpec}
	 * labeled alternative in {@link SplcParser#specifier}.
	 * @param ctx the parse tree
	 */
	void exitCharSpec(SplcParser.CharSpecContext ctx);
	/**
	 * Enter a parse tree produced by the {@code StructDeclSpec}
	 * labeled alternative in {@link SplcParser#specifier}.
	 * @param ctx the parse tree
	 */
	void enterStructDeclSpec(SplcParser.StructDeclSpecContext ctx);
	/**
	 * Exit a parse tree produced by the {@code StructDeclSpec}
	 * labeled alternative in {@link SplcParser#specifier}.
	 * @param ctx the parse tree
	 */
	void exitStructDeclSpec(SplcParser.StructDeclSpecContext ctx);
	/**
	 * Enter a parse tree produced by the {@code FullStructSpec}
	 * labeled alternative in {@link SplcParser#specifier}.
	 * @param ctx the parse tree
	 */
	void enterFullStructSpec(SplcParser.FullStructSpecContext ctx);
	/**
	 * Exit a parse tree produced by the {@code FullStructSpec}
	 * labeled alternative in {@link SplcParser#specifier}.
	 * @param ctx the parse tree
	 */
	void exitFullStructSpec(SplcParser.FullStructSpecContext ctx);
	/**
	 * Enter a parse tree produced by the {@code PointerVar}
	 * labeled alternative in {@link SplcParser#varDec}.
	 * @param ctx the parse tree
	 */
	void enterPointerVar(SplcParser.PointerVarContext ctx);
	/**
	 * Exit a parse tree produced by the {@code PointerVar}
	 * labeled alternative in {@link SplcParser#varDec}.
	 * @param ctx the parse tree
	 */
	void exitPointerVar(SplcParser.PointerVarContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ArrayVar}
	 * labeled alternative in {@link SplcParser#varDec}.
	 * @param ctx the parse tree
	 */
	void enterArrayVar(SplcParser.ArrayVarContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ArrayVar}
	 * labeled alternative in {@link SplcParser#varDec}.
	 * @param ctx the parse tree
	 */
	void exitArrayVar(SplcParser.ArrayVarContext ctx);
	/**
	 * Enter a parse tree produced by the {@code SimpleVar}
	 * labeled alternative in {@link SplcParser#varDec}.
	 * @param ctx the parse tree
	 */
	void enterSimpleVar(SplcParser.SimpleVarContext ctx);
	/**
	 * Exit a parse tree produced by the {@code SimpleVar}
	 * labeled alternative in {@link SplcParser#varDec}.
	 * @param ctx the parse tree
	 */
	void exitSimpleVar(SplcParser.SimpleVarContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ParenVar}
	 * labeled alternative in {@link SplcParser#varDec}.
	 * @param ctx the parse tree
	 */
	void enterParenVar(SplcParser.ParenVarContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ParenVar}
	 * labeled alternative in {@link SplcParser#varDec}.
	 * @param ctx the parse tree
	 */
	void exitParenVar(SplcParser.ParenVarContext ctx);
	/**
	 * Enter a parse tree produced by {@link SplcParser#funcArgs}.
	 * @param ctx the parse tree
	 */
	void enterFuncArgs(SplcParser.FuncArgsContext ctx);
	/**
	 * Exit a parse tree produced by {@link SplcParser#funcArgs}.
	 * @param ctx the parse tree
	 */
	void exitFuncArgs(SplcParser.FuncArgsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code BlockStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterBlockStmt(SplcParser.BlockStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code BlockStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitBlockStmt(SplcParser.BlockStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code VarDecStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterVarDecStmt(SplcParser.VarDecStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code VarDecStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitVarDecStmt(SplcParser.VarDecStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code IfStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterIfStmt(SplcParser.IfStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code IfStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitIfStmt(SplcParser.IfStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code WhileStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterWhileStmt(SplcParser.WhileStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code WhileStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitWhileStmt(SplcParser.WhileStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ReturnStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterReturnStmt(SplcParser.ReturnStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ReturnStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitReturnStmt(SplcParser.ReturnStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ExprStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterExprStmt(SplcParser.ExprStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ExprStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitExprStmt(SplcParser.ExprStmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link SplcParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterExpression(SplcParser.ExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link SplcParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitExpression(SplcParser.ExpressionContext ctx);
}