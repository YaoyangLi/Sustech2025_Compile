// Generated from Splc.g4 by ANTLR 4.13.2
package generated.Splc;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link SplcParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface SplcVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link SplcParser#program}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitProgram(SplcParser.ProgramContext ctx);
	/**
	 * Visit a parse tree produced by the {@code FuncDef}
	 * labeled alternative in {@link SplcParser#globalDef}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncDef(SplcParser.FuncDefContext ctx);
	/**
	 * Visit a parse tree produced by the {@code FuncDecl}
	 * labeled alternative in {@link SplcParser#globalDef}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncDecl(SplcParser.FuncDeclContext ctx);
	/**
	 * Visit a parse tree produced by the {@code GlobalVarDef}
	 * labeled alternative in {@link SplcParser#globalDef}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGlobalVarDef(SplcParser.GlobalVarDefContext ctx);
	/**
	 * Visit a parse tree produced by the {@code GlobalStructDecl}
	 * labeled alternative in {@link SplcParser#globalDef}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGlobalStructDecl(SplcParser.GlobalStructDeclContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IntSpec}
	 * labeled alternative in {@link SplcParser#specifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntSpec(SplcParser.IntSpecContext ctx);
	/**
	 * Visit a parse tree produced by the {@code CharSpec}
	 * labeled alternative in {@link SplcParser#specifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharSpec(SplcParser.CharSpecContext ctx);
	/**
	 * Visit a parse tree produced by the {@code StructDeclSpec}
	 * labeled alternative in {@link SplcParser#specifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStructDeclSpec(SplcParser.StructDeclSpecContext ctx);
	/**
	 * Visit a parse tree produced by the {@code FullStructSpec}
	 * labeled alternative in {@link SplcParser#specifier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFullStructSpec(SplcParser.FullStructSpecContext ctx);
	/**
	 * Visit a parse tree produced by the {@code PointerVar}
	 * labeled alternative in {@link SplcParser#varDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPointerVar(SplcParser.PointerVarContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ArrayVar}
	 * labeled alternative in {@link SplcParser#varDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayVar(SplcParser.ArrayVarContext ctx);
	/**
	 * Visit a parse tree produced by the {@code SimpleVar}
	 * labeled alternative in {@link SplcParser#varDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSimpleVar(SplcParser.SimpleVarContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ParenVar}
	 * labeled alternative in {@link SplcParser#varDec}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenVar(SplcParser.ParenVarContext ctx);
	/**
	 * Visit a parse tree produced by {@link SplcParser#funcArgs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFuncArgs(SplcParser.FuncArgsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code BlockStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockStmt(SplcParser.BlockStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code VarDecStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVarDecStmt(SplcParser.VarDecStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code IfStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfStmt(SplcParser.IfStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code WhileStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileStmt(SplcParser.WhileStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ReturnStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnStmt(SplcParser.ReturnStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ExprStmt}
	 * labeled alternative in {@link SplcParser#statement}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprStmt(SplcParser.ExprStmtContext ctx);
	/**
	 * Visit a parse tree produced by {@link SplcParser#expression}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExpression(SplcParser.ExpressionContext ctx);
}